scp -i spark-clusters_key.pem -rp azureuser@20.83.161.61:/home/azureuser/output src/
